require('dotenv').config();
const express = require('express');
const app = express();
app.use(express.json()); // Parse JSON bodies

let todos = [
  { id: 1, task: 'Learn Node.js', completed: false },
  { id: 2, task: 'Build CRUD API', completed: false },
  {
    id: 3,
    task: 'Thank the Betechified Team dor the program',
    completed: true,
  },
];

// GET All – Read
app.get('/todos/:id', (req, res) => {
  const id = parseInt(req.params.id); // Get a single todo
  res.status(200).json(todos[id - 1]); // Send array as JSON
});

// POST New – Create
app.post('/todos', (req, res) => {
  const { task, completed = false } = req.body;
  const newTodo = { id: todos.length + 1, task, completed }; // Auto-ID
  if (!task) {
    return res.status(400).json({ error: 'Missing Task Field!' });
  }
  if (task.length === 1) {
    return res.status(400).json({ error: 'A character is not a todo' });
  }
  todos.push(newTodo);
  res.status(201).json(newTodo); // Echo back
});

// PATCH Update – Partial
// app.patch('/todos/:id', (req, res) => {
//   const todo = todos.find((t) => t.id === parseInt(req.params.id)); // Array.find()
//   if (!todo) return res.status(404).json({ message: 'Todo not found' });
//   Object.assign(todo, req.body); // Merge: e.g., {completed: true}
//   res.status(200).json(todo);
// });

// DELETE Remove
// app.delete('/todos/:id', (req, res) => {
//   const id = parseInt(req.params.id);
//   const initialLength = todos.length;
//   todos = todos.filter((t) => t.id !== id); // Array.filter() – non-destructive
//   if (todos.length === initialLength)
//     return res.status(404).json({ error: 'Not found' });
//   res.status(204).send(); // Silent success
// });

app.get('/todos/active', (req, res) => {
  const activeTodos = todos.filter((todo) => todo.completed === false);
  res.json(activeTodos); // Custom Read!
});

app.use((err, req, res, next) => {
  res.status(500).json({ error: 'Server error!' });
});

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`Server on port ${PORT}`));
